package com.capgi.NewSpringBoot.dto;

public enum CoustomerType {
    GOLD,SILVER, PLATINUM
}
