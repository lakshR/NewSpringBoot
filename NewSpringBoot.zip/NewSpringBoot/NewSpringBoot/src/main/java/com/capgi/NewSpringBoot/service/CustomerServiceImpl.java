package com.capgi.NewSpringBoot.service;

import com.capgi.NewSpringBoot.dto.CustomerDTO;
import com.capgi.NewSpringBoot.entity.Address;
import com.capgi.NewSpringBoot.entity.Customer;
import com.capgi.NewSpringBoot.exception.CustomerNotFoundException;
import com.capgi.NewSpringBoot.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    @Transactional
    public void createCustomerRecord(CustomerDTO customerDTO) {
        Customer customer= new Customer();
        customer.setFirstName(customerDTO.getFirstName());
        customer.setLastName(customerDTO.getLastName());
        customer.setEmail(customerDTO.getEmail());
        customer.setCoustomerType(customerDTO.getCoustomerType());

        Address address = new Address();
        address.setStreet(customerDTO.getAddressDTO().getStreet());
        address.setCity(customerDTO.getAddressDTO().getCity());
        customer.setAddress(address);
        System.out.println(customer);
        customerRepository.save(customer);
    }

    @Override
    public CustomerDTO getCustomer(int id){
        Customer customer=null;
     CustomerDTO customerDTO = new CustomerDTO();
        Optional<Customer> optionalCustomerDTO= customerRepository.findById(id);
        if(optionalCustomerDTO.isPresent()){
            customer=optionalCustomerDTO.get();
           customerDTO.setFirstName(customer.getFirstName());
           customerDTO.setLastName(customer.getLastName());
           customerDTO.setEmail(customer.getEmail());
           customerDTO.setCoustomerType(customer.getCoustomerType());
           return  customerDTO;
        }
        else {
            throw  new CustomerNotFoundException("No one found :"+id);
        }

    }

    @Override
    public ResponseEntity<HttpStatus> deleteCustomer(int id) {
        customerRepository.deleteById(id);
        System.out.println("Customer with"+id+" Deleted");
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<HttpStatus> deleteAll(){
        customerRepository.deleteAll();
        System.out.println("All data deleted");
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }



    @Override
    public Customer getCustomerById(int customerId) {
        return null;
    }

    @Override
    public ResponseEntity<Customer> update(int id, Customer customer) {
        Optional<Customer> customerdata= customerRepository.findById(id);
        if(customerdata.isPresent()){
            Customer customer1 = customerdata.get();
            customer1.setCoustomerType(customer.getCoustomerType());
            customer1.setEmail(customer.getEmail());
            customer1.setFirstName(customer.getFirstName());
            customer1.setLastName(customer.getLastName());
            return  new ResponseEntity<>(customerRepository.save(customer1),HttpStatus.OK);
        }
        else {
            throw  new CustomerNotFoundException("No one found :"+id);
        }
    }


    @Override
    public List<CustomerDTO> fetchAllCustomer() {
        List<Customer> customers = customerRepository.findAll();
        List<CustomerDTO> customerDTOList = customers.stream().map(customer -> {
            CustomerDTO customerDTO = new CustomerDTO();
            customerDTO.setFirstName(customer.getFirstName());
            customerDTO.setLastName(customer.getLastName());
            customerDTO.setEmail(customer.getEmail());
            customerDTO.setCoustomerType(customer.getCoustomerType());
            return customerDTO;
        }).collect(Collectors.toList());

return  customerDTOList;
    }
}
