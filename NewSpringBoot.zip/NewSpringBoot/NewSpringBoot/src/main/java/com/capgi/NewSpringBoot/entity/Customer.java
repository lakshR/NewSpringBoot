package com.capgi.NewSpringBoot.entity;


import com.capgi.NewSpringBoot.dto.CoustomerType;

import javax.persistence.*;
import java.util.Objects;
import java.util.List;

@Entity
@Table(name = "capg_customers2")

public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer customerID;
    private String firstName;
    private String lastName;
    private String email;

    @Enumerated(EnumType.STRING)
    private CoustomerType coustomerType;
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="address_id",unique=true)
    private Address address;

    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(unique=false)
    private List<Product> product;


    public Customer(){}

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CoustomerType getCoustomerType() {
        return coustomerType;
    }

    public void setCoustomerType(CoustomerType coustomerType) {
        this.coustomerType = coustomerType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(coustomerType, email, firstName, lastName);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Customer other = (Customer) obj;
        return coustomerType == other.coustomerType && Objects.equals(email, other.email)
                && Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName);
    }

    @Override
    public String toString() {
        return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", " +
                "customerType="
                + coustomerType + "Address=" + address+ "Product=" + product+ "]";
    }

    public Integer getCustomerId() {

        return customerID;
    }

    public void setCustomerId(Integer customerId ) {
        this.customerID=customerId;
    }
}