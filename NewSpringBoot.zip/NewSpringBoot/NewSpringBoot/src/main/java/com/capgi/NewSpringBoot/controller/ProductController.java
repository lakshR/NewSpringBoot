package com.capgi.NewSpringBoot.controller;

public class ProductController{
}
