package com.capgi.NewSpringBoot.dto;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.util.Objects;

public class CustomerDTO {
    //    private Integer customerId;
    @NotBlank(message = "FirstName cant be empty")
    private String firstName;

    @NotBlank(message = "lastName cant be empty")
    private String lastName;

    @NotBlank(message = "Email cant be empty")
    @Email(message ="enter valid email")
    private String email;
//    @Enumerated(EnumType.STRING)

    private CoustomerType coustomerType;

@Valid
    private AddressDTO addressDTO;

    public CustomerDTO() {
    }

//    public Integer getCustomerId() {
//        return customerId;
//    }
//
//    public void setCustomerId(Integer customerId) {
//        this.customerId = customerId;
//    }

    public AddressDTO getAddressDTO() {
        return addressDTO;
    }

    public void setAddressDTO(AddressDTO addressDTO) {
        this.addressDTO = addressDTO;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CoustomerType getCoustomerType() {
        return coustomerType;
    }

    public void setCoustomerType(CoustomerType coustomerType) {
        this.coustomerType = coustomerType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerDTO that = (CustomerDTO) o;
        return Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName)
                && Objects.equals(email, that.email) && coustomerType == that.coustomerType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, email, coustomerType);
    }

    @Override
    public String toString() {
        return "CustomerDTO{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", customerType=" + coustomerType+
                '}';
    }
}